# ev_simulator/attack_modes.py
# Attack 1, 2, 3 pre-built payloads
