# ev_simulator/session_manager.py
# session lifecycle logic
